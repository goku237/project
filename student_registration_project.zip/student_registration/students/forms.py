from django import forms
from .models import Student

class StudentRegistrationForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['first_name', 'last_name', 'email', 'age', 'course']

    def clean_age(self):
        age = self.cleaned_data.get('age')
        if age < 5:
            raise forms.ValidationError("Age must be at least 5.")
        return age
