# Simplified settings.py placeholder
